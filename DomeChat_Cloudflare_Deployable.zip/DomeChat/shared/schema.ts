import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Message Types
export enum MessageType {
  SYSTEM = 'system',
  USER = 'user',
  STRANGER = 'stranger'
}

// Chat Message Interface
export interface ChatMessage {
  type: MessageType;
  text: string;
  timestamp: string;
}

// WebSocket Message Types
export enum WSMessageType {
  CONNECT = 'connect',
  MATCH_REQUEST = 'match_request',
  MATCH_SUCCESS = 'match_success',
  MESSAGE = 'message',
  DISCONNECT = 'disconnect',
  USER_TYPING = 'user_typing',
  ERROR = 'error'
}

// WebSocket Message Interface
export interface WSMessage {
  type: WSMessageType;
  payload?: any;
}
