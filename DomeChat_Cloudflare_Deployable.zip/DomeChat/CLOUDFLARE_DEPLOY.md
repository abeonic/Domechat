# Deploying Dome Chat to Cloudflare Workers

This guide provides step-by-step instructions for deploying the Dome Chat application to Cloudflare Workers.

## Prerequisites

- A Cloudflare account with Workers enabled
- Wrangler CLI installed (already included in the project)
- Node.js and npm

## Deployment Steps

### 1. Login to Cloudflare

First, you need to authenticate with Cloudflare:

```bash
npx wrangler login
```

This will open a browser window where you can log in to your Cloudflare account and authorize Wrangler.

### 2. Configure Your Worker

The project already includes a `wrangler.toml` file with the basic configuration. Review it to make sure it matches your needs.

For Durable Objects to work properly, you may need to enable them in your Cloudflare Workers account.

### 3. Publish Your Worker

Build the project and deploy it to Cloudflare Workers:

```bash
npm run build
npx wrangler deploy
```

### 4. Verify Your Deployment

After deployment, Wrangler will output a URL where your worker is running. Visit this URL to verify that your application is working correctly.

## Configuration Files

- `wrangler.toml`: Main configuration file for Cloudflare Workers
- `cloudflare/ChatManagerDO.js`: Implementation of the ChatManager as a Durable Object
- `worker.js`: Main worker script that handles HTTP requests and WebSocket connections

## Troubleshooting

### Common Issues

1. **Durable Objects Not Working**: Make sure Durable Objects are enabled in your Cloudflare account.

2. **WebSocket Connection Issues**: Ensure that your client is connecting to the right WebSocket URL (`wss://your-worker-domain.workers.dev/ws`).

3. **Deployment Failures**: Check the error messages in the Wrangler output. Common issues include:
   - Missing permissions
   - Invalid configuration in wrangler.toml
   - Syntax errors in your worker code

4. **Resource Limits**: Be aware of the resource limits in your Cloudflare Workers plan.

### Debugging

You can use the Cloudflare Workers dashboard to monitor your worker's performance and check logs for any errors.

## Updating Your Deployment

To update your deployed worker:

1. Make your changes to the code
2. Build the project: `npm run build`
3. Deploy the changes: `npx wrangler deploy`

## Additional Resources

- [Cloudflare Workers Documentation](https://developers.cloudflare.com/workers/)
- [Durable Objects Documentation](https://developers.cloudflare.com/workers/learning/using-durable-objects/)
- [WebSockets in Cloudflare Workers](https://developers.cloudflare.com/workers/learning/using-websockets/)