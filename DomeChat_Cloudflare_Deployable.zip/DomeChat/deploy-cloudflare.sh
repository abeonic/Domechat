#!/bin/bash
# Script to deploy Dome Chat to Cloudflare Workers
#
# IMPORTANT: Before running this script, you need to:
# 1. Sign up for a Cloudflare account (if you don't already have one)
# 2. Enable Cloudflare Workers in your account
# 3. Install wrangler CLI globally: npm install -g wrangler
# 4. Log in to your Cloudflare account: wrangler login

# Check if wrangler is installed
if ! command -v npx wrangler &> /dev/null
then
    echo "Wrangler is not installed. Installing..."
    npm install -g wrangler
fi

# Build the project
echo "Building project..."
npm run build

# Log in to Cloudflare (if not already logged in)
echo "Please make sure you're logged in to Cloudflare..."
npx wrangler whoami || npx wrangler login

# Create KV namespace if it doesn't exist
echo "Creating KV namespace for chat sessions..."
npx wrangler kv:namespace create "CHAT_SESSIONS" || true

# Update wrangler.toml with KV namespace ID
KV_ID=$(npx wrangler kv:namespace list | grep CHAT_SESSIONS | awk '{print $1}')
if [ ! -z "$KV_ID" ]; then
    # Uncomment the KV namespace ID line in wrangler.toml and replace with the actual ID
    sed -i "s/# id = \"your-kv-namespace-id\"/id = \"$KV_ID\"/" wrangler.toml
    echo "Updated wrangler.toml with KV namespace ID: $KV_ID"
fi

# Deploy the worker
echo "Deploying to Cloudflare Workers..."
npx wrangler deploy

# Print deployment information
echo "Deployment complete!"
echo "Your chat application is available at: https://dome-chat.workers.dev"
echo "Remember to add your domain in the Cloudflare Dashboard if you want to use a custom domain."