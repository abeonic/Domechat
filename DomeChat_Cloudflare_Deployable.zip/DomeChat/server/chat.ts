import { WebSocket } from 'ws';
import * as WebSocketModule from 'ws';
import { WSMessageType } from '@shared/schema';
import { nanoid } from 'nanoid';

interface User {
  id: string;
  socket: WebSocket;
  partnerId?: string;
}

export class ChatManager {
  private users: Map<string, User>;
  private waitingUsers: string[];

  constructor() {
    this.users = new Map();
    this.waitingUsers = [];
  }

  public addUser(socket: WebSocket): string {
    const userId = nanoid();
    this.users.set(userId, { id: userId, socket });
    
    // Send connect message with session ID and online count
    this.sendToUser(userId, {
      type: WSMessageType.CONNECT,
      payload: {
        sessionId: userId,
        onlineCount: this.getOnlineCount()
      }
    });
    
    return userId;
  }

  public removeUser(userId: string): void {
    const user = this.users.get(userId);
    
    // If user was waiting, remove from waiting list
    const waitingIndex = this.waitingUsers.indexOf(userId);
    if (waitingIndex !== -1) {
      this.waitingUsers.splice(waitingIndex, 1);
    }
    
    // If user was chatting with someone, notify partner
    if (user?.partnerId) {
      this.sendToUser(user.partnerId, {
        type: WSMessageType.DISCONNECT
      });
      
      // Remove partner reference
      const partner = this.users.get(user.partnerId);
      if (partner) {
        partner.partnerId = undefined;
      }
    }
    
    // Remove user
    this.users.delete(userId);
  }

  public matchRequest(userId: string): void {
    const user = this.users.get(userId);
    if (!user) return;
    
    // If already waiting, don't add again
    if (this.waitingUsers.includes(userId)) return;
    
    // If already matched, don't match again
    if (user.partnerId) {
      this.sendToUser(userId, {
        type: WSMessageType.ERROR,
        payload: { message: 'Already in a chat' }
      });
      return;
    }
    
    // If there's someone waiting, match them
    if (this.waitingUsers.length > 0) {
      const partnerId = this.waitingUsers.shift()!;
      const partner = this.users.get(partnerId);
      
      // Make sure partner still exists and isn't already matched
      if (partner && !partner.partnerId) {
        this.matchUsers(userId, partnerId);
      } else {
        // If partner is no longer valid, add this user to waiting list
        this.waitingUsers.push(userId);
      }
    } else {
      // No one waiting, add to waiting list
      this.waitingUsers.push(userId);
    }
  }

  public sendMessage(fromUserId: string, text: string): void {
    const user = this.users.get(fromUserId);
    if (!user || !user.partnerId) return;
    
    this.sendToUser(user.partnerId, {
      type: WSMessageType.MESSAGE,
      payload: { text }
    });
  }

  public sendTypingStatus(fromUserId: string, isTyping: boolean): void {
    const user = this.users.get(fromUserId);
    if (!user || !user.partnerId) return;
    
    this.sendToUser(user.partnerId, {
      type: WSMessageType.USER_TYPING,
      payload: { isTyping }
    });
  }

  public disconnect(userId: string): void {
    const user = this.users.get(userId);
    if (!user || !user.partnerId) return;
    
    const partnerId = user.partnerId;
    
    // Notify partner
    this.sendToUser(partnerId, {
      type: WSMessageType.DISCONNECT
    });
    
    // Clear partner references
    user.partnerId = undefined;
    const partner = this.users.get(partnerId);
    if (partner) {
      partner.partnerId = undefined;
    }
  }

  private matchUsers(userId1: string, userId2: string): void {
    const user1 = this.users.get(userId1);
    const user2 = this.users.get(userId2);
    
    if (!user1 || !user2) return;
    
    // Update partner references
    user1.partnerId = userId2;
    user2.partnerId = userId1;
    
    // Notify both users of successful match
    this.sendToUser(userId1, {
      type: WSMessageType.MATCH_SUCCESS,
      payload: { partnerId: userId2 }
    });
    
    this.sendToUser(userId2, {
      type: WSMessageType.MATCH_SUCCESS,
      payload: { partnerId: userId1 }
    });
  }

  private sendToUser(userId: string, message: any): void {
    const user = this.users.get(userId);
    if (!user) return;
    
    const socket = user.socket;
    // WebSocket connection state 1 means OPEN
    if (socket.readyState === 1) {
      socket.send(JSON.stringify(message));
    }
  }

  public broadcastOnlineCount(): void {
    const count = this.getOnlineCount();
    this.users.forEach(user => {
      this.sendToUser(user.id, {
        type: WSMessageType.CONNECT,
        payload: { onlineCount: count }
      });
    });
  }

  public getOnlineCount(): number {
    return this.users.size;
  }
}
