import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import * as WebSocketModule from 'ws';
import { ChatManager } from './chat';
import { WSMessageType } from '@shared/schema';

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Create WebSocket server on a distinct path
  // Using a path helps avoid conflicts with Vite's HMR websocket
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws',
    // Add permessage-deflate for better performance
    perMessageDeflate: {
      zlibDeflateOptions: {
        chunkSize: 1024,
        memLevel: 7,
        level: 3
      },
      zlibInflateOptions: {
        chunkSize: 10 * 1024
      },
      clientNoContextTakeover: true,
      serverNoContextTakeover: true,
      serverMaxWindowBits: 10,
      concurrencyLimit: 10,
      threshold: 1024
    }
  });
  
  // Initialize chat manager
  const chatManager = new ChatManager();
  
  // Log WebSocket server started
  console.log('WebSocket server initialized on path: /ws');
  
  // Broadcast online count periodically
  setInterval(() => {
    chatManager.broadcastOnlineCount();
  }, 30000); // Every 30 seconds
  
  // Handle WebSocket connections
  wss.on('connection', (socket: WebSocket, request) => {
    console.log('New WebSocket connection established');
    
    // Add user to chat manager
    const userId = chatManager.addUser(socket);
    console.log(`User ${userId} connected`);
    
    socket.on('message', (data: WebSocketModule.Data) => {
      try {
        const message = JSON.parse(data.toString());
        console.log(`Received message from ${userId}:`, message.type);
        
        switch (message.type) {
          case WSMessageType.MATCH_REQUEST:
            console.log(`User ${userId} requested a match`);
            chatManager.matchRequest(userId);
            break;
            
          case WSMessageType.MESSAGE:
            if (message.payload && message.payload.text) {
              chatManager.sendMessage(userId, message.payload.text);
            }
            break;
            
          case WSMessageType.USER_TYPING:
            if (message.payload && typeof message.payload.isTyping === 'boolean') {
              chatManager.sendTypingStatus(userId, message.payload.isTyping);
            }
            break;
            
          case WSMessageType.DISCONNECT:
            console.log(`User ${userId} requested disconnect`);
            chatManager.disconnect(userId);
            break;
            
          default:
            console.warn(`Unknown message type: ${message.type}`);
            break;
        }
      } catch (error) {
        console.error('Error processing message:', error);
      }
    });
    
    socket.on('close', () => {
      console.log(`WebSocket connection closed for user ${userId}`);
      chatManager.removeUser(userId);
    });
    
    socket.on('error', (error) => {
      console.error(`WebSocket error for user ${userId}:`, error);
      chatManager.removeUser(userId);
    });
  });
  
  // Add a simple status endpoint
  app.get('/api/status', (req, res) => {
    res.json({
      status: 'ok',
      users: chatManager.getOnlineCount()
    });
  });

  return httpServer;
}
