/**
 * Dome Chat - Cloudflare Worker
 * 
 * This worker handles both the WebSocket connections and serves the static assets
 * for the Dome Chat application.
 */

// Import from shared schema
// Note: For Cloudflare Workers, you might need to adjust these imports based on your build setup
const MessageType = {
  SYSTEM: 'system',
  USER: 'user',
  STRANGER: 'stranger'
};

const WSMessageType = {
  CONNECT: 'connect',
  MATCH_REQUEST: 'match_request',
  MATCH_SUCCESS: 'match_success',
  MESSAGE: 'message',
  DISCONNECT: 'disconnect',
  USER_TYPING: 'user_typing',
  ERROR: 'error'
};

/**
 * ChatManager Cloudflare Worker implementation
 */
class ChatManager {
  constructor() {
    this.users = new Map(); // userId -> WebSocket
    this.waitingUsers = [];
    this.sessions = new Map(); // userId -> partnerId
  }

  /**
   * Add a user to the chat system
   */
  addUser(userId, socket) {
    this.users.set(userId, socket);
    
    // Send connection confirmation
    this.sendToUser(userId, {
      type: WSMessageType.CONNECT,
      payload: {
        userId,
        onlineCount: this.getOnlineCount()
      }
    });
    
    // Broadcast updated online count
    this.broadcastOnlineCount();
    
    return userId;
  }

  /**
   * Remove a user from the chat system
   */
  removeUser(userId) {
    // If user was waiting, remove from waiting list
    const waitingIndex = this.waitingUsers.indexOf(userId);
    if (waitingIndex !== -1) {
      this.waitingUsers.splice(waitingIndex, 1);
    }
    
    // If user was in a chat, disconnect their partner
    const partnerId = this.sessions.get(userId);
    if (partnerId) {
      this.sessions.delete(userId);
      this.sessions.delete(partnerId);
      
      // Notify partner of disconnection
      this.sendToUser(partnerId, {
        type: WSMessageType.DISCONNECT,
        payload: {
          reason: 'Partner disconnected'
        }
      });
      
      // Send system message to partner
      this.sendToUser(partnerId, {
        type: WSMessageType.MESSAGE,
        payload: {
          type: MessageType.SYSTEM,
          text: 'Stranger has disconnected',
          timestamp: new Date().toISOString()
        }
      });
    }
    
    // Remove user
    this.users.delete(userId);
    
    // Broadcast updated online count
    this.broadcastOnlineCount();
  }

  /**
   * Match a user with another user
   */
  matchRequest(userId) {
    // If user is already in a session, ignore
    if (this.sessions.has(userId)) {
      return;
    }
    
    // Add user to waiting list
    this.waitingUsers.push(userId);
    
    // Try to match users
    this.tryMatching();
  }

  /**
   * Try to match waiting users
   */
  tryMatching() {
    // Need at least 2 users to match
    if (this.waitingUsers.length < 2) {
      return;
    }
    
    // Get two users from waiting list
    const userId1 = this.waitingUsers.shift();
    const userId2 = this.waitingUsers.shift();
    
    // Make sure both users are still connected
    if (this.users.has(userId1) && this.users.has(userId2)) {
      this.matchUsers(userId1, userId2);
    } else {
      // If one user disconnected, put the other back in waiting
      if (this.users.has(userId1)) {
        this.waitingUsers.unshift(userId1);
      }
      if (this.users.has(userId2)) {
        this.waitingUsers.unshift(userId2);
      }
    }
  }

  /**
   * Match two users together
   */
  matchUsers(userId1, userId2) {
    // Create session
    this.sessions.set(userId1, userId2);
    this.sessions.set(userId2, userId1);
    
    // Notify users of match
    this.sendToUser(userId1, {
      type: WSMessageType.MATCH_SUCCESS,
      payload: {
        partnerId: userId2
      }
    });
    
    this.sendToUser(userId2, {
      type: WSMessageType.MATCH_SUCCESS,
      payload: {
        partnerId: userId1
      }
    });
    
    // Send system messages
    const message = {
      type: MessageType.SYSTEM,
      text: 'You are now chatting with a stranger',
      timestamp: new Date().toISOString()
    };
    
    this.sendToUser(userId1, {
      type: WSMessageType.MESSAGE,
      payload: message
    });
    
    this.sendToUser(userId2, {
      type: WSMessageType.MESSAGE,
      payload: message
    });
  }

  /**
   * Send a message from one user to their partner
   */
  sendMessage(fromUserId, text) {
    const partnerId = this.sessions.get(fromUserId);
    if (!partnerId) {
      return;
    }
    
    const timestamp = new Date().toISOString();
    
    // Send message to sender
    this.sendToUser(fromUserId, {
      type: WSMessageType.MESSAGE,
      payload: {
        type: MessageType.USER,
        text,
        timestamp
      }
    });
    
    // Send message to partner
    this.sendToUser(partnerId, {
      type: WSMessageType.MESSAGE,
      payload: {
        type: MessageType.STRANGER,
        text,
        timestamp
      }
    });
  }

  /**
   * Send typing status from one user to their partner
   */
  sendTypingStatus(fromUserId, isTyping) {
    const partnerId = this.sessions.get(fromUserId);
    if (!partnerId) {
      return;
    }
    
    // Send typing status to partner
    this.sendToUser(partnerId, {
      type: WSMessageType.USER_TYPING,
      payload: {
        isTyping
      }
    });
  }

  /**
   * Disconnect a user from their chat
   */
  disconnect(userId) {
    const partnerId = this.sessions.get(userId);
    if (!partnerId) {
      return;
    }
    
    // Remove session
    this.sessions.delete(userId);
    this.sessions.delete(partnerId);
    
    // Notify partner of disconnection
    this.sendToUser(partnerId, {
      type: WSMessageType.DISCONNECT,
      payload: {
        reason: 'Partner disconnected'
      }
    });
    
    // Send system message to partner
    this.sendToUser(partnerId, {
      type: WSMessageType.MESSAGE,
      payload: {
        type: MessageType.SYSTEM,
        text: 'Stranger has disconnected',
        timestamp: new Date().toISOString()
      }
    });
    
    // Send confirmation to user
    this.sendToUser(userId, {
      type: WSMessageType.DISCONNECT,
      payload: {
        reason: 'You disconnected'
      }
    });
  }

  /**
   * Send a message to a specific user
   */
  sendToUser(userId, message) {
    const socket = this.users.get(userId);
    if (socket && socket.readyState === 1) { // 1 = OPEN
      socket.send(JSON.stringify(message));
    }
  }

  /**
   * Broadcast online count to all users
   */
  broadcastOnlineCount() {
    const count = this.getOnlineCount();
    
    // Send to all connected users
    for (const [userId, socket] of this.users.entries()) {
      if (socket && socket.readyState === 1) { // 1 = OPEN
        socket.send(JSON.stringify({
          type: 'online_count',
          payload: {
            count
          }
        }));
      }
    }
  }

  /**
   * Get the current number of online users
   */
  getOnlineCount() {
    return this.users.size;
  }
}

// Create a single instance of ChatManager
const chatManager = new ChatManager();

/**
 * Cloudflare Worker entry point
 */
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    
    // Handle WebSocket connections on /ws path
    if (url.pathname === '/ws') {
      if (request.headers.get('Upgrade') !== 'websocket') {
        return new Response('Expected Upgrade: websocket', { status: 426 });
      }
      
      // Create WebSocket pair
      const [client, server] = Object.values(new WebSocketPair());
      
      // Accept the WebSocket connection
      server.accept();
      
      // Generate a unique user ID
      const userId = crypto.randomUUID();
      console.log(`User ${userId} connected`);
      
      // Add user to chat manager
      chatManager.addUser(userId, server);
      
      // Handle WebSocket messages
      server.addEventListener('message', (event) => {
        try {
          const message = JSON.parse(event.data);
          console.log(`Received message from ${userId}:`, message.type);
          
          switch (message.type) {
            case WSMessageType.MATCH_REQUEST:
              console.log(`User ${userId} requested a match`);
              chatManager.matchRequest(userId);
              break;
              
            case WSMessageType.MESSAGE:
              if (message.payload && message.payload.text) {
                chatManager.sendMessage(userId, message.payload.text);
              }
              break;
              
            case WSMessageType.USER_TYPING:
              if (message.payload && typeof message.payload.isTyping === 'boolean') {
                chatManager.sendTypingStatus(userId, message.payload.isTyping);
              }
              break;
              
            case WSMessageType.DISCONNECT:
              console.log(`User ${userId} requested disconnect`);
              chatManager.disconnect(userId);
              break;
              
            default:
              console.warn(`Unknown message type: ${message.type}`);
              break;
          }
        } catch (error) {
          console.error('Error processing message:', error);
        }
      });
      
      // Handle WebSocket close
      server.addEventListener('close', () => {
        console.log(`WebSocket connection closed for user ${userId}`);
        chatManager.removeUser(userId);
      });
      
      // Handle WebSocket errors
      server.addEventListener('error', (error) => {
        console.error(`WebSocket error for user ${userId}:`, error);
        chatManager.removeUser(userId);
      });
      
      // Return the client WebSocket
      return new Response(null, {
        status: 101,
        webSocket: client,
      });
    }
    
    // Handle API endpoints
    if (url.pathname === '/api/status') {
      return new Response(JSON.stringify({
        status: 'ok',
        users: chatManager.getOnlineCount()
      }), {
        headers: {
          'Content-Type': 'application/json',
        },
      });
    }
    
    // Serve static assets
    return env.ASSETS.fetch(request);
  },
};