import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import DomeChat from "@/components/DomeChat";

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <div className="min-h-screen w-full flex items-center justify-center bg-dark-900">
          <DomeChat />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
