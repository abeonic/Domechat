import { useState, useEffect, useCallback, useRef } from 'react';
import { ChatMessage, MessageType, WSMessageType } from '@shared/schema';
import { ChatState, ScreenState, WebSocketEvent } from '@/lib/types';
import { formatTime } from '@/lib/utils';

export function useChat() {
  const [state, setState] = useState<ChatState>({
    currentScreen: ScreenState.HOME,
    connected: false,
    messages: [],
    onlineCount: 1245, // Default online count
  });
  
  const socketRef = useRef<WebSocket | null>(null);
  const waitingTimeoutRef = useRef<number | null>(null);

  // Initialize WebSocket connection with reconnection logic
  const initSocket = useCallback(() => {
    // If we already have an active socket connection, don't create a new one
    // WebSocket.OPEN = 1, WebSocket.CONNECTING = 0
    if (socketRef.current && (
      socketRef.current.readyState === 1 || 
      socketRef.current.readyState === 0
    )) {
      console.log('WebSocket already connected or connecting - reusing existing connection');
      return;
    }
    
    // Close any existing socket that might be in a closing or closed state
    if (socketRef.current) {
      try {
        socketRef.current.close();
      } catch (e) {
        console.error('Error closing existing socket:', e);
      }
    }

    // Fix WebSocket URL format to ensure proper connection
    // This will work for both local development and cloud deployment (Render, Replit, etc.)
    const isSecure = window.location.protocol === "https:";
    const protocol = isSecure ? "wss:" : "ws:";
    
    // Use the same host for WebSocket connection - this works across platforms
    // including Render, Replit, Vercel, etc.
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log('Connecting to WebSocket:', wsUrl);
    const socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log('WebSocket connection established');
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data) as WebSocketEvent;
        handleWebSocketMessage(message);
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setState(prev => ({
        ...prev,
        currentScreen: ScreenState.HOME,
        connected: false,
        error: 'Connection error. Please try again later.'
      }));
    };

    socket.onclose = () => {
      console.log('WebSocket connection closed');
      // If we were in chat and the connection closed unexpectedly
      if (state.currentScreen === ScreenState.CHAT) {
        addSystemMessage('Connection lost. Please try again.');
        setState(prev => ({
          ...prev,
          currentScreen: ScreenState.HOME,
          connected: false,
        }));
      }
    };

    socketRef.current = socket;
  }, [state.currentScreen]);

  // Handle incoming websocket messages
  const handleWebSocketMessage = useCallback((message: WebSocketEvent) => {
    switch (message.type) {
      case WSMessageType.CONNECT:
        setState(prev => ({
          ...prev,
          sessionId: message.payload.sessionId,
          onlineCount: message.payload.onlineCount || prev.onlineCount
        }));
        break;

      case WSMessageType.MATCH_SUCCESS:
        clearWaitingTimeout();
        setState(prev => ({
          ...prev,
          currentScreen: ScreenState.CHAT,
          connected: true,
          partnerId: message.payload.partnerId,
          messages: [
            ...prev.messages,
            {
              type: MessageType.SYSTEM,
              text: "You're now chatting with a random stranger",
              timestamp: formatTime()
            }
          ]
        }));
        break;

      case WSMessageType.MESSAGE:
        setState(prev => ({
          ...prev,
          strangerTyping: false,
          messages: [
            ...prev.messages,
            {
              type: MessageType.STRANGER,
              text: message.payload.text,
              timestamp: formatTime()
            }
          ]
        }));
        break;

      case WSMessageType.USER_TYPING:
        setState(prev => ({
          ...prev,
          strangerTyping: message.payload.isTyping
        }));
        break;

      case WSMessageType.DISCONNECT:
        addSystemMessage('Stranger has disconnected');
        setTimeout(() => {
          setState(prev => ({
            ...prev,
            currentScreen: ScreenState.HOME,
            connected: false,
            partnerId: undefined,
            strangerTyping: false
          }));
        }, 1500);
        break;

      case WSMessageType.ERROR:
        setState(prev => ({
          ...prev,
          error: message.payload.message,
          currentScreen: message.payload.fatal ? ScreenState.HOME : prev.currentScreen
        }));
        break;

      default:
        console.warn('Unknown message type:', message.type);
    }
  }, []);

  // Clear waiting timeout if exists
  const clearWaitingTimeout = useCallback(() => {
    if (waitingTimeoutRef.current) {
      clearTimeout(waitingTimeoutRef.current);
      waitingTimeoutRef.current = null;
    }
  }, []);

  // Start looking for a chat partner
  const startChat = useCallback(() => {
    initSocket();
    
    setState(prev => ({
      ...prev,
      currentScreen: ScreenState.WAITING,
      messages: []
    }));

    // Safety timeout in case match doesn't happen within reasonable time
    waitingTimeoutRef.current = window.setTimeout(() => {
      addSystemMessage('Taking longer than usual to find a partner. Please try again.');
      setState(prev => ({
        ...prev,
        currentScreen: ScreenState.HOME
      }));
    }, 30000);

    // Send match request once socket is ready
    const checkSocketAndSendRequest = () => {
      if (socketRef.current?.readyState === 1) { // 1 = OPEN
        socketRef.current.send(JSON.stringify({
          type: WSMessageType.MATCH_REQUEST
        }));
      } else if (socketRef.current) {
        // Try again after a short delay
        setTimeout(checkSocketAndSendRequest, 100);
      }
    };
    
    checkSocketAndSendRequest();
  }, [initSocket]);

  // Cancel waiting for a match
  const cancelWaiting = useCallback(() => {
    clearWaitingTimeout();
    setState(prev => ({
      ...prev,
      currentScreen: ScreenState.HOME
    }));
  }, [clearWaitingTimeout]);

  // Disconnect from current chat
  const disconnect = useCallback(() => {
    if (socketRef.current && socketRef.current.readyState === 1) { // 1 = OPEN
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.DISCONNECT
      }));
    }
    
    addSystemMessage('You disconnected');
    setState(prev => ({
      ...prev,
      currentScreen: ScreenState.HOME,
      connected: false,
      partnerId: undefined,
      strangerTyping: false
    }));
  }, []);

  // Send a chat message
  const sendMessage = useCallback((text: string) => {
    if (!text.trim()) return;
    
    if (state.connected && socketRef.current && socketRef.current.readyState === 1) { // 1 = OPEN
      const message: ChatMessage = {
        type: MessageType.USER,
        text: text,
        timestamp: formatTime()
      };
      
      // Add message to local state
      setState(prev => ({
        ...prev,
        messages: [...prev.messages, message],
        isTyping: false
      }));
      
      // Send message to server
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.MESSAGE,
        payload: { text }
      }));
    }
  }, [state.connected]);

  // Handle typing indicator
  const setTyping = useCallback((isTyping: boolean) => {
    if (state.connected && socketRef.current && socketRef.current.readyState === 1) { // 1 = OPEN
      setState(prev => ({
        ...prev,
        isTyping
      }));
      
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.USER_TYPING,
        payload: { isTyping }
      }));
    }
  }, [state.connected]);

  // Add a system message to the chat
  const addSystemMessage = useCallback((text: string) => {
    setState(prev => ({
      ...prev,
      messages: [
        ...prev.messages,
        {
          type: MessageType.SYSTEM,
          text,
          timestamp: formatTime()
        }
      ]
    }));
  }, []);

  // Initialize WebSocket on component mount
  useEffect(() => {
    initSocket();
    
    return () => {
      clearWaitingTimeout();
      if (socketRef.current) {
        socketRef.current.close();
      }
    };
  }, [initSocket, clearWaitingTimeout]);

  return {
    state,
    startChat,
    cancelWaiting,
    disconnect,
    sendMessage,
    setTyping
  };
}
