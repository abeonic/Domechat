import { useCallback, useEffect, useRef, useState } from 'react';
import { ChatState, ScreenState } from '@/lib/types';
import { ChatMessage, WSMessageType, MessageType } from '@shared/schema';
import { formatTime } from '@/lib/utils';

/**
 * Hook for managing chat state with Cloudflare Workers WebSocket
 */
export function useCloudflareChat() {
  const [state, setState] = useState<ChatState>({
    currentScreen: ScreenState.HOME,
    connected: false,
    messages: [],
    onlineCount: 0
  });
  
  const socketRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  /**
   * Connect to the WebSocket server
   */
  const connect = useCallback(() => {
    if (socketRef.current) {
      console.log('WebSocket already connected or connecting - reusing existing connection');
      return;
    }
    
    // Determine the correct WebSocket URL
    // For Cloudflare Workers, use the same domain but with wss:// protocol
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log('Connecting to WebSocket:', wsUrl);
    
    // Create a new WebSocket connection
    const socket = new WebSocket(wsUrl);
    socketRef.current = socket;
    
    socket.onopen = () => {
      console.log('WebSocket connection established');
      setState(prev => ({
        ...prev,
        connected: true,
        error: undefined
      }));
    };
    
    socket.onclose = () => {
      console.log('WebSocket connection closed');
      setState(prev => ({
        ...prev,
        connected: false,
        currentScreen: ScreenState.HOME
      }));
      socketRef.current = null;
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setState(prev => ({
        ...prev,
        error: 'Failed to connect to chat server. Please try again later.'
      }));
    };
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      handleWebSocketMessage(data);
    };
  }, []);
  
  /**
   * Handle incoming WebSocket messages
   */
  const handleWebSocketMessage = useCallback((message: any) => {
    console.log('Received message:', message);
    
    switch (message.type) {
      case WSMessageType.CONNECT:
        setState(prev => ({
          ...prev,
          sessionId: message.payload.userId,
          onlineCount: message.payload.onlineCount
        }));
        break;
        
      case 'online_count':
        setState(prev => ({
          ...prev,
          onlineCount: message.payload.count
        }));
        break;
        
      case WSMessageType.MATCH_SUCCESS:
        setState(prev => ({
          ...prev,
          currentScreen: ScreenState.CHAT,
          partnerId: message.payload.partnerId
        }));
        break;
        
      case WSMessageType.MESSAGE:
        const messageObj: ChatMessage = {
          type: message.payload.type,
          text: message.payload.text,
          timestamp: message.payload.timestamp
        };
        
        setState(prev => ({
          ...prev,
          messages: [...prev.messages, messageObj]
        }));
        break;
        
      case WSMessageType.USER_TYPING:
        setState(prev => ({
          ...prev,
          strangerTyping: message.payload.isTyping
        }));
        break;
        
      case WSMessageType.DISCONNECT:
        setState(prev => ({
          ...prev,
          currentScreen: ScreenState.HOME,
          partnerId: undefined,
          messages: [],
          strangerTyping: false
        }));
        break;
        
      case WSMessageType.ERROR:
        setState(prev => ({
          ...prev,
          error: message.payload.message
        }));
        break;
        
      default:
        console.warn('Unknown message type:', message.type);
        break;
    }
  }, []);
  
  /**
   * Start a chat by requesting a match
   */
  const startChat = useCallback(() => {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      connect();
      // Set a small delay to ensure the connection is established
      setTimeout(() => {
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
          socketRef.current.send(JSON.stringify({
            type: WSMessageType.MATCH_REQUEST
          }));
          
          setState(prev => ({
            ...prev,
            currentScreen: ScreenState.WAITING,
            messages: []
          }));
        }
      }, 500);
    } else {
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.MATCH_REQUEST
      }));
      
      setState(prev => ({
        ...prev,
        currentScreen: ScreenState.WAITING,
        messages: []
      }));
    }
  }, [connect]);
  
  /**
   * Send a chat message
   */
  const sendMessage = useCallback((text: string) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.MESSAGE,
        payload: {
          text
        }
      }));
    }
  }, []);
  
  /**
   * Disconnect from the current chat
   */
  const disconnect = useCallback(() => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.DISCONNECT
      }));
    }
  }, []);
  
  /**
   * Send typing indicator
   */
  const sendTypingStatus = useCallback((isTyping: boolean) => {
    // Clear any existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = null;
    }
    
    // Update local state
    setState(prev => ({
      ...prev,
      isTyping
    }));
    
    // Send typing status to server
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: WSMessageType.USER_TYPING,
        payload: {
          isTyping
        }
      }));
      
      // If user is typing, set a timeout to automatically set isTyping to false after 3 seconds
      if (isTyping) {
        typingTimeoutRef.current = setTimeout(() => {
          sendTypingStatus(false);
        }, 3000);
      }
    }
  }, []);
  
  // Connect to WebSocket when the component mounts
  useEffect(() => {
    connect();
    
    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
        socketRef.current = null;
      }
      
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = null;
      }
    };
  }, [connect]);
  
  return {
    state,
    startChat,
    sendMessage,
    disconnect,
    sendTypingStatus
  };
}