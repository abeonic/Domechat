import { ChatMessage, WSMessageType } from "@shared/schema";

export enum ScreenState {
  HOME = 'home',
  WAITING = 'waiting',
  CHAT = 'chat'
}

export interface ChatState {
  currentScreen: ScreenState;
  connected: boolean;
  messages: ChatMessage[];
  onlineCount: number;
  sessionId?: string;
  partnerId?: string;
  isTyping?: boolean;
  strangerTyping?: boolean;
  error?: string;
}

export interface WebSocketEvent {
  type: WSMessageType;
  payload?: any;
}
