import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format time for chat messages (HH:MM AM/PM)
export const formatTime = (): string => {
  const now = new Date();
  return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
};

// Generate fake online user count (only for display purposes)
export const getRandomOnlineCount = (): number => {
  return Math.floor(Math.random() * 500) + 1000;
};

// Format online count with commas
export const formatOnlineCount = (count: number): string => {
  return count.toLocaleString();
};
