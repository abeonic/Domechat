import React, { useState, useRef, useEffect } from 'react';
import { MessageType, ChatMessage } from '@shared/schema';
import { Button } from '@/components/ui/button';
import Message from './Message';

interface ChatScreenProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onDisconnect: () => void;
  onTyping: (isTyping: boolean) => void;
  strangerTyping?: boolean;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ 
  messages, 
  onSendMessage, 
  onDisconnect,
  onTyping,
  strangerTyping
}) => {
  const [messageText, setMessageText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const typingTimeoutRef = useRef<number | null>(null);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Auto-focus input when chat screen mounts
  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setMessageText(e.target.value);
    
    // Handle typing indicator logic
    if (!typingTimeoutRef.current) {
      onTyping(true);
    }
    
    // Clear existing timeout
    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }
    
    // Set new timeout - stop typing indicator after 2 seconds of inactivity
    typingTimeoutRef.current = window.setTimeout(() => {
      onTyping(false);
      typingTimeoutRef.current = null;
    }, 2000);
  };

  const handleSendMessage = () => {
    if (messageText.trim()) {
      onSendMessage(messageText);
      setMessageText('');
      
      // Clear typing indicator
      if (typingTimeoutRef.current) {
        clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = null;
        onTyping(false);
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  return (
    <div className="bg-dark-800 rounded-xl shadow-2xl overflow-hidden flex flex-col h-[550px]">
      {/* Chat Header */}
      <div className="p-4 bg-dark-700 border-b border-dark-600 flex items-center justify-between">
        <div className="flex items-center">
          <div className="w-2 h-2 rounded-full bg-green-500 mr-2"></div>
          <h2 className="font-medium text-white">Chat with <span className="text-primary-400">Stranger</span></h2>
        </div>
        <Button 
          onClick={onDisconnect} 
          variant="destructive"
          size="sm"
          className="py-1.5 px-4 bg-red-600 hover:bg-red-700 text-white text-sm font-medium rounded-lg transition-all"
        >
          Disconnect
        </Button>
      </div>
      
      {/* Chat Messages Area */}
      <div className="chat-messages flex-1 overflow-y-auto p-4 space-y-2">
        {messages.map((message, index) => (
          <Message key={index} message={message} />
        ))}
        
        {/* Stranger typing indicator */}
        {strangerTyping && (
          <div className="flex items-center space-x-2 mb-2">
            <div className="flex-shrink-0 h-8 w-8 rounded-full bg-dark-600 flex items-center justify-center">
              <span className="text-xs font-medium">S</span>
            </div>
            <div className="bg-dark-600 px-4 py-2 rounded-lg">
              <div className="flex space-x-1">
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse"></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-75"></div>
                <div className="w-2 h-2 rounded-full bg-gray-400 animate-pulse delay-150"></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>
      
      {/* Chat Input Area */}
      <div className="p-4 bg-dark-700 border-t border-dark-600">
        <div className="flex space-x-2">
          <input 
            ref={inputRef}
            type="text" 
            value={messageText}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-dark-600 text-white placeholder-gray-400 rounded-lg border border-dark-500 focus:border-primary-500 focus:ring focus:ring-primary-500 focus:ring-opacity-20 px-4 py-3 outline-none transition-all"
            placeholder="Type a message..."
          />
          <Button 
            onClick={handleSendMessage} 
            className="bg-primary-600 hover:bg-primary-700 text-white rounded-lg px-4 flex items-center justify-center transition-all"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen;
