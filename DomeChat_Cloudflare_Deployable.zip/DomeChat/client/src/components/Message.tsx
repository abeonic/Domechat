import React from 'react';
import { ChatMessage, MessageType } from '@shared/schema';

interface MessageProps {
  message: ChatMessage;
}

const Message: React.FC<MessageProps> = ({ message }) => {
  const { type, text, timestamp } = message;

  if (type === MessageType.SYSTEM) {
    return (
      <div className="flex justify-center my-2">
        <div className="bg-dark-700 text-gray-400 text-sm px-4 py-2 rounded-full">
          {text}
        </div>
      </div>
    );
  }

  if (type === MessageType.USER) {
    return (
      <div className="flex items-end justify-end space-x-2 mb-3">
        <div className="max-w-[75%]">
          <div className="bg-primary-600 px-4 py-2 rounded-lg">
            <p className="text-white break-words">{text}</p>
          </div>
          <div className="flex justify-end">
            <span className="text-xs text-gray-500 mt-1">{timestamp}</span>
          </div>
        </div>
      </div>
    );
  }

  // Stranger message
  return (
    <div className="flex items-end space-x-2 mb-3">
      <div className="flex-shrink-0 h-8 w-8 rounded-full bg-dark-600 flex items-center justify-center">
        <span className="text-xs font-medium">S</span>
      </div>
      <div className="max-w-[75%]">
        <div className="bg-dark-600 px-4 py-2 rounded-lg">
          <p className="text-white break-words">{text}</p>
        </div>
        <span className="text-xs text-gray-500 mt-1">{timestamp}</span>
      </div>
    </div>
  );
};

export default Message;
