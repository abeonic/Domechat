import React from 'react';
import { Button } from '@/components/ui/button';

interface WaitingScreenProps {
  onCancel: () => void;
}

const WaitingScreen: React.FC<WaitingScreenProps> = ({ onCancel }) => {
  return (
    <div className="bg-dark-800 rounded-xl shadow-2xl overflow-hidden">
      <div className="p-6 text-center border-b border-dark-600">
        <h1 className="text-2xl font-semibold text-white">Finding a stranger...</h1>
      </div>
      
      <div className="p-8 flex flex-col items-center">
        <div className="w-24 h-24 rounded-full bg-dark-700 flex items-center justify-center animate-pulse-custom mb-6">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        
        <p className="text-gray-300 mb-8">Please wait while we connect you with someone random...</p>
        
        <Button 
          onClick={onCancel} 
          variant="outline"
          className="py-3 px-6 bg-dark-600 hover:bg-dark-500 text-white font-medium rounded-lg transition-all"
        >
          Cancel
        </Button>
      </div>
    </div>
  );
};

export default WaitingScreen;
