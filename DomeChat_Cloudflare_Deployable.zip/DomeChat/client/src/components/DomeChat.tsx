import React, { useEffect } from 'react';
import { useChat } from '@/hooks/useChat';
import { ScreenState } from '@/lib/types';
import HomeScreen from './HomeScreen';
import WaitingScreen from './WaitingScreen';
import ChatScreen from './ChatScreen';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

const DomeChat: React.FC = () => {
  const { 
    state, 
    startChat, 
    cancelWaiting, 
    disconnect, 
    sendMessage,
    setTyping
  } = useChat();
  
  return (
    <div className="w-full max-w-lg mx-auto p-4">
      {state.error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{state.error}</AlertDescription>
        </Alert>
      )}
      
      {state.currentScreen === ScreenState.HOME && (
        <HomeScreen 
          onStartChat={startChat} 
          onlineCount={state.onlineCount}
        />
      )}
      
      {state.currentScreen === ScreenState.WAITING && (
        <WaitingScreen 
          onCancel={cancelWaiting} 
        />
      )}
      
      {state.currentScreen === ScreenState.CHAT && (
        <ChatScreen 
          messages={state.messages}
          onSendMessage={sendMessage}
          onDisconnect={disconnect}
          onTyping={setTyping}
          strangerTyping={state.strangerTyping}
        />
      )}
    </div>
  );
};

export default DomeChat;
