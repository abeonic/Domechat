# Deploying Dome Chat to Render

If you're encountering the error "Couldn't find a package.json file in '/opt/render/project/src'", follow these steps for a successful deployment:

## Option 1: Deploy using render.yaml (Blueprint)

1. Make sure your repository structure looks like:
   ```
   dome-chat-repo/
   ├── package.json
   ├── render.yaml
   └── ... (other files)
   ```

2. When deploying using Render Blueprints, make sure to select the root of your repository, not a subdirectory.

## Option 2: Manual Deployment

1. Go to [Render Dashboard](https://dashboard.render.com/)
2. Click "New" and select "Web Service"
3. Connect your GitHub repository
4. Configure the following settings:
   - **Name**: dome-chat (or your preferred name)
   - **Region**: Choose the region closest to your users
   - **Branch**: main (or your default branch)
   - **Root Directory**: Leave empty (to use the repository root)
   - **Runtime**: Node
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `npm start`
   
5. Add the environment variable:
   - Key: `NODE_ENV`
   - Value: `production`

6. Click "Create Web Service"

## Option 3: Upload Files Directly

If you're still encountering issues, you can deploy directly from your local machine:

1. Go to [Render Dashboard](https://dashboard.render.com/)
2. Click "New" and select "Web Service"
3. Select "Upload Files" instead of connecting a repository
4. Create a ZIP file of your entire project (make sure package.json is in the root of the ZIP)
5. Upload the ZIP file
6. Configure the settings as in Option 2
7. Click "Create Web Service"

## Troubleshooting

If you're still experiencing issues:

1. Verify your package.json is at the root of your repository
2. Check that all paths in your code use relative paths (not absolute paths)
3. Make sure the port is properly configured to use `process.env.PORT` 
4. Contact Render support with your specific deployment logs