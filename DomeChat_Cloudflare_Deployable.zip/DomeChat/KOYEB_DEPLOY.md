# Deploying Dome Chat to Koyeb

This guide provides step-by-step instructions for deploying the Dome Chat application to Koyeb.

## Prerequisites

- A Koyeb account (sign up at [koyeb.com](https://www.koyeb.com))
- Git repository with your Dome Chat code

## Deployment Steps

### 1. Clone the Repository

Make sure you have the latest version of the code:

```bash
git clone <your-repository-url>
cd dome-chat
```

### 2. Create a New Koyeb App

1. Log in to your Koyeb account
2. Click on "Create App"
3. Select "GitHub" as the deployment method
4. Connect your GitHub account and select your repository
5. Configure the app:
   - **Name**: dome-chat (or your preferred name)
   - **Region**: Choose the region closest to your users
   - **Instance Type**: nano (recommended for starting)
   - **Environment Variables**:
     - `NODE_ENV`: production
     - `PORT`: 5000

### 3. Advanced Settings (if needed)

If the automatic detection doesn't work, you can configure the deployment manually:

1. In the Koyeb deployment interface, click on "Advanced Settings"
2. Set the following configuration:
   - **Builder**: nixpacks
   - **Build Command**: npm run build
   - **Start Command**: npm start
   - **Port**: 5000

### 4. Deploy the Application

1. Click "Deploy"
2. Wait for the build and deployment process to complete
3. Once completed, Koyeb will provide you with a URL to access your application

## Troubleshooting

If you encounter issues during deployment:

1. **Build failures**: Check the build logs for errors related to dependencies or Node.js version
2. **Runtime errors**: Check the runtime logs to identify issues that occur after deployment
3. **Connection issues**: Ensure that the PORT environment variable is set correctly
4. **WebSocket issues**: Verify that your WebSocket path (/ws) is correctly configured and that your client is connecting to the right URL

## Configuration Files

The repository includes several configuration files specifically for Koyeb deployment:

- **koyeb.yaml**: Main configuration file for Koyeb deployment
- **nixpacks.toml**: Instructions for building the application
- **.koyeb.yaml**: Additional Koyeb-specific settings
- **Procfile**: Specifies the command to start the application
- **.node-version**: Specifies the Node.js version
- **app.json**: Describes the application for platform detection

## Updating Your Deployment

To update your deployed application after making changes:

1. Push your changes to your GitHub repository
2. Koyeb will automatically detect changes and redeploy your application
3. Monitor the deployment in the Koyeb dashboard

## Support

If you need further assistance:
- Check the [Koyeb documentation](https://www.koyeb.com/docs)
- Visit the [Koyeb GitHub examples](https://github.com/koyeb/examples)