/**
 * Dome Chat - Cloudflare Worker (Site Handler)
 * 
 * This version of the worker is specifically for handling static site assets
 * when deployed to Cloudflare Workers.
 */

import { getAssetFromKV } from '@cloudflare/kv-asset-handler';

/**
 * The DEBUG flag will do two things:
 * 1. We will skip caching on the edge, which makes it easier to debug
 * 2. We will return more detailed error messages to the client
 */
const DEBUG = false;

/**
 * Handle requests for static assets
 */
async function handleAsset(request, event) {
  try {
    const options = {
      cacheControl: {
        // Always cache static assets for 24 hours
        browserTTL: 24 * 60 * 60,
        // Don't cache on the edge in debug mode
        edgeTTL: DEBUG ? 0 : 24 * 60 * 60,
        // Don't bypass the cache for range requests
        bypassCache: false,
      },
    };
    
    const page = await getAssetFromKV(event, options);
    
    // Add CORS headers for font files if needed
    const url = new URL(request.url);
    if (url.pathname.match(/\.(woff|woff2|ttf|otf)$/)) {
      const response = new Response(page.body, page);
      response.headers.set('Access-Control-Allow-Origin', '*');
      return response;
    }
    
    return page;
  } catch (error) {
    // If an error is thrown try to serve the fallback HTML page
    if (DEBUG) {
      return new Response(error.message || error.toString(), {
        status: 500,
      });
    }
    
    try {
      let notFoundResponse = await getAssetFromKV(event, {
        mapRequestToAsset: (req) => new Request(`${new URL(req.url).origin}/404.html`, req),
      });
      
      return new Response(notFoundResponse.body, {
        ...notFoundResponse,
        status: 404,
      });
    } catch (e) {
      return new Response('Not Found', { status: 404 });
    }
  }
}

/**
 * Cloudflare Worker entry point
 */
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    
    // Handle WebSocket connections on /ws path
    if (url.pathname === '/ws') {
      // Forward to WebSocket handler
      return env.CHAT_MANAGER.fetch(request);
    }
    
    // Handle API endpoints
    if (url.pathname.startsWith('/api/')) {
      // Forward to API handler
      return env.CHAT_MANAGER.fetch(request);
    }
    
    // Serve static assets
    return handleAsset(request, ctx);
  },
};