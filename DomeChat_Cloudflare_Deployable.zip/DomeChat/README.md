# Dome Chat

A real-time anonymous chat platform with random user matching, similar to Omegle.

## Features

- Anonymous chat (no login required)
- Random matching with strangers
- Real-time messaging
- Typing indicators
- Dark theme UI

## Technology Stack

- Frontend: React, TypeScript, Tailwind CSS
- Backend: Node.js, Express
- WebSockets for real-time communication

## Deployment to Render

This project is configured for easy deployment on [Render](https://render.com/).

### Option 1: Deploy from GitHub

1. Fork this repository to your GitHub account
2. Go to [Render Dashboard](https://dashboard.render.com/) and create a new account or sign in
3. Click "New +" and select "Blueprint"
4. Connect your GitHub account and select your forked repository
5. Render will automatically detect the `render.yaml` configuration and set up the service
6. Click "Apply" to start the deployment

### Option 2: Manual Deployment

1. Go to [Render Dashboard](https://dashboard.render.com/) and create a new account or sign in
2. Click "New +" and select "Web Service"
3. Connect your GitHub repository
4. Fill in the following details:
   - Name: `dome-chat` (or your preferred name)
   - Environment: `Node`
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`
5. Add the environment variable:
   - `NODE_ENV`: `production`
6. Click "Create Web Service" to deploy

### Verify Deployment

Once deployed, your application will be available at `https://dome-chat.onrender.com` (or a similar URL based on your service name).

## Local Development

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/dome-chat.git
   cd dome-chat
   ```

2. Install dependencies:
   ```
   npm install
   ```

3. Start the development server:
   ```
   npm run dev
   ```

4. Open your browser and navigate to `http://localhost:5000`

## License

MIT License