#!/bin/bash

# This script is used by Render to start the application
# It ensures we're in the right directory with the server files

# Print current directory for debugging
echo "Current directory: $(pwd)"
echo "Listing directory contents:"
ls -la

# Check if package.json exists
if [ -f "package.json" ]; then
  echo "Found package.json in current directory"
  npm start
else
  # Try to find package.json
  PKG_DIR=$(find . -name "package.json" -not -path "*/node_modules/*" -not -path "*/\.*" | head -1 | xargs dirname)
  
  if [ -n "$PKG_DIR" ]; then
    echo "Found package.json in $PKG_DIR"
    cd "$PKG_DIR"
    npm start
  else
    echo "ERROR: Could not find package.json in this repository"
    exit 1
  fi
fi